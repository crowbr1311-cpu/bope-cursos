'use strict';
const c = require('../lib/common');

/* GET /bootstrap — tudo que a sessão atual pode ler, em uma chamada só.
   Usuário comum: cursos, cargos e os próprios certificados. Administrador: também usuários, certificados, anotações e punições. */
exports.bootstrap = c.wrap('user', async ({ me }) => {
  const admin = me.role === 'admin';
  const [cargos, courses, certs] = await Promise.all([c.listCargos(), c.listCourses(), c.listCerts()]);
  const out = {
    user: c.pub(me), cargos, courses,
    myCerts: certs.filter((x) => c.lc(x.userId) === c.lc(me.id)),
    users: [], certs: [], notes: [], punicoes: []
  };
  if (admin) {
    const [users, notes, puns] = await Promise.all([c.listUsers(), c.listRecs('NOTE'), c.listRecs('PUN')]);
    out.users = users.map(c.pub); out.certs = certs; out.notes = notes; out.punicoes = puns;
  }
  return c.ok(out);
});
