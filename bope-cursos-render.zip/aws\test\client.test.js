'use strict';
/* Roda o auth.js REAL (do site) contra os handlers, com fetch e sessionStorage simulados. */
process.env.DB_DRIVER = 'memory';
process.env.JWT_SECRET = 'segredo-de-teste-com-mais-de-32-caracteres';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'), path = require('path'), vm = require('vm');
const c = require('../src/lib/common');

/* tabela de rotas lida do template.yaml, para provar que caminhos/métodos do cliente existem */
const tpl = fs.readFileSync(path.join(__dirname, '../template.yaml'), 'utf8');
const routes = [...tpl.matchAll(/Handler: handlers\/(\S+)[\s\S]*?Method: (\w+), Path: "([^"]+)"/g)].map((m) => {
  let fn = require('../src/handlers/' + m[1].split('.')[0]);
  m[1].split('.').slice(1).forEach((k) => { fn = fn[k]; });
  return { fn, method: m[2], re: new RegExp('^' + m[3].replace(/\{(\w+)\}/g, '(?<$1>[^/]+)') + '$') };
});

function makeBrowser() {
  const store = {};
  const win = {
    BOPE_CONFIG: { apiUrl: 'https://api.test/prod/' },
    sessionStorage: { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: (k) => { delete store[k]; } },
    location: { replace(u) { win.went = u; }, pathname: '/', search: '' },
    async fetch(url, opts) {
      const p = new URL(url).pathname.replace(/^\/prod/, '');
      const hit = routes.map((r) => ({ r, m: r.re.exec(p) })).find((x) => x.m && x.r.method === opts.method);
      if (!hit) return { status: 404, json: async () => { throw new Error('sem rota'); } };
      const raw = hit.m.groups ? Object.assign({}, hit.m.groups) : {};
      const res = await hit.r.fn({ headers: Object.fromEntries(Object.entries(opts.headers || {}).map(([k, v]) => [k.toLowerCase(), v])), body: opts.body, pathParameters: raw });
      return { status: res.statusCode, json: async () => JSON.parse(res.body) };
    }
  };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../../auth.js'), 'utf8'), { window: win, JSON, Promise, Date, encodeURIComponent, String, Object, Array });
  return win;
}

test.beforeEach(async () => {
  c.db._reset(); c.resetSeedCache(); await c.ensureSeed();
  const cr = await c.newCreds('senhaAdmin1');
  await c.db.put({ pk: 'USER', sk: 'adm', id: 'ADM', nome: 'Chefe Teste', cargo: 'CEO', instrutor: false, role: 'admin', fixo: false, salt: cr.salt, hash: cr.hash, criadoEm: '2026-01-01' });
});

test('fluxo completo pelo cliente: login, CRUDs, certificado, usuário comum, backup, logout', async () => {
  const w = makeBrowser(), Auth = w.Auth;
  await Auth.ready;
  assert.equal(Auth.current(), null);

  const bad = await Auth.login('Chefe Teste', 'errada123');
  assert.equal(bad.ok, false); assert.equal(bad.code, 'badpass');
  assert.equal((await Auth.login('chefe teste', 'senhaAdmin1')).ok, true);
  assert.equal(Auth.current().id, 'ADM');
  assert.equal(Auth.listCourses().length, 6);
  assert.equal(JSON.stringify(Auth.cargos()), JSON.stringify(['Diretor', 'Instrutor', 'Membro']));

  /* mutações atualizam o cache antes de resolver */
  assert.equal((await Auth.addCargo('Sargento')).ok, true);
  assert.ok(Auth.cargos().includes('Sargento'));
  assert.equal((await Auth.removeCargo('Sargento')).ok, true);
  assert.equal((await Auth.addUser({ id: 'maria', nome: 'Maria Souza', cargo: 'Membro', instrutor: false, senha: 'senhaMaria1' })).ok, true);
  assert.ok(Auth.listUsers().some((u) => u.id === 'maria'));
  const dup = await Auth.addUser({ id: 'maria', nome: 'Outra', cargo: 'Membro', senha: 'senhaMaria1' });
  assert.match(dup.error, /ID/);

  const curso = Auth.listCourses()[0];
  assert.equal((await Auth.addCert({ userId: 'maria', cursoId: curso.id, instrutorId: '', data: '2026-11-20' })).ok, true);
  const cert = Auth.listCerts()[0];
  assert.equal(Auth.getCert(cert.id).user.nome, 'Maria Souza');
  assert.equal((await Auth.addNote({ nome: 'Maria', texto: 'ok' })).ok, true);
  assert.equal(Auth.listNotes().length, 1);
  assert.equal((await Auth.addPunicao({ autor: 'Chefe', punido: 'Maria', motivo: 'Motivo qualquer' })).ok, true);
  assert.equal(Auth.listPunicoes().length, 1);

  const txt = await Auth.exportBackup();
  assert.equal(JSON.parse(txt).users.length, 3);
  assert.match((await Auth.importBackup('não é json')).error, /inválido/);
  assert.equal((await Auth.importBackup(txt)).ok, true);
  assert.equal(Auth.listUsers().length, 3);

  /* usuário comum: só enxerga o que é seu e não consegue chamar rotas de admin */
  const w2 = makeBrowser(), U = w2.Auth;
  await U.ready;
  assert.equal((await U.login('maria souza', 'senhaMaria1')).ok, true);
  assert.equal(U.myCerts().length, 1);
  assert.equal(JSON.stringify([U.listUsers(), U.listCerts(), U.listNotes(), U.listPunicoes()]), '[[],[],[],[]]');
  assert.equal(U.getCert(cert.id).user.id, 'maria');
  const deny = await U.addCargo('Hack');
  assert.match(deny.error, /administrador/);
  assert.equal(await U.exportBackup(), '');

  /* sessão vencida no servidor (usuário apagado) derruba a sessão local */
  await Auth.deleteUser('maria');
  const w3 = makeBrowser(); await w3.Auth.ready;
  assert.equal((await w3.Auth.login('maria souza', 'senhaMaria1')).ok, false);

  Auth.logout();
  assert.equal(w.went, 'login.html');
  assert.equal(Auth.current(), null);
});

test('API sem configuração ou fora do ar devolve erro amigável', async () => {
  const w = makeBrowser(); w.BOPE_CONFIG.apiUrl = '';
  const w2 = makeBrowser();
  const Auth2 = w2.Auth; await Auth2.ready;
  w2.fetch = async () => { throw new Error('offline'); };
  assert.match((await Auth2.login('x', 'y')).error, /conectar/);
});

test('resposta que não é JSON (ex. página 404 do S3) mostra status e dica, não erro genérico', async () => {
  const w = makeBrowser(); await w.Auth.ready;
  w.fetch = async () => ({ status: 404, json: async () => { throw new SyntaxError('Unexpected token <'); } });
  const r = await w.Auth.login('x', 'y');
  assert.equal(r.ok, false);
  assert.match(r.error, /HTTP 404/);
  assert.match(r.error, /CloudFront/);
});
