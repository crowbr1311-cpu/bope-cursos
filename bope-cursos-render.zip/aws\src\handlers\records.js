'use strict';
/* Anotações (NOTE) e punições (PUN): mesmo CRUD, só mudam o tipo e a validação. Somente administrador. */
const c = require('../lib/common');

function make(pk, validate) {
  return {
    create: c.wrap('admin', async ({ me, body }) => {
      const v = validate(body); if (v.error) return c.fail(v.error);
      const id = c.rid();
      await c.db.put(Object.assign({ pk, sk: id, id, criadoEm: new Date().toISOString(), registradoPor: me.nome }, v.value));
      return c.ok({ id });
    }),
    update: c.wrap('admin', async ({ me, params, body }) => {
      const v = validate(body); if (v.error) return c.fail(v.error);
      const r = await c.db.get(pk, params.id);
      if (!r) return c.fail('Registro não encontrado.', 404);
      await c.db.put(Object.assign(r, v.value, { editadoEm: new Date().toISOString(), editadoPor: me.nome }));
      return c.ok();
    }),
    remove: c.wrap('admin', async ({ params }) => {
      if (!(await c.db.get(pk, params.id))) return c.fail('Registro não encontrado.', 404);
      await c.db.del(pk, params.id);
      return c.ok();
    })
  };
}
exports.notes = make('NOTE', c.vNote);
exports.punicoes = make('PUN', c.vPun);
