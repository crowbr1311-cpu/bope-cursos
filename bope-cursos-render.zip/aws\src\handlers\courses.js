'use strict';
const c = require('../lib/common');

/* POST /courses */
exports.create = c.wrap('admin', async ({ body }) => {
  const v = c.vCourse(body); if (v.error) return c.fail(v.error);
  const id = 'c' + c.rid();
  await c.db.put(Object.assign({ pk: 'COURSE', sk: id, id, ordem: Date.now() }, v.value));
  return c.ok({ id });
});

/* PUT /courses/{id} */
exports.update = c.wrap('admin', async ({ params, body }) => {
  const v = c.vCourse(body); if (v.error) return c.fail(v.error);
  const old = await c.db.get('COURSE', params.id);
  if (!old) return c.fail('Curso não encontrado.', 404);
  await c.db.put(Object.assign({ pk: 'COURSE', sk: old.sk, id: old.id, ordem: old.ordem }, v.value));
  return c.ok();
});

/* DELETE /courses/{id} */
exports.remove = c.wrap('admin', async ({ params }) => {
  if (!(await c.db.get('COURSE', params.id))) return c.fail('Curso não encontrado.', 404);
  await c.db.del('COURSE', params.id);
  return c.ok();
});
