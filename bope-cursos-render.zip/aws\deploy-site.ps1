﻿# Envia os arquivos do site para o S3 e limpa o cache do CloudFront no Windows PowerShell.
# Uso (dentro da pasta aws):  .\deploy-site.ps1 -Stack "bope-cursos"
param(
    [string]$Stack = "bope-cursos"
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
Set-Location $ProjectRoot

Write-Host "Obtendo dados do stack '$Stack'..." -ForegroundColor Cyan

$bucket = aws cloudformation describe-stacks --stack-name $Stack --query "Stacks[0].Outputs[?OutputKey=='SiteBucket'].OutputValue" --output text
$dist = aws cloudformation describe-stacks --stack-name $Stack --query "Stacks[0].Outputs[?OutputKey=='DistributionId'].OutputValue" --output text
$siteUrl = aws cloudformation describe-stacks --stack-name $Stack --query "Stacks[0].Outputs[?OutputKey=='SiteUrl'].OutputValue" --output text

if (-not $bucket -or $bucket -eq "None") {
    Write-Error "Stack '$Stack' não encontrado ou sem saída SiteBucket."
    exit 1
}

Write-Host "Sincronizando arquivos do site com o S3 ($bucket)..." -ForegroundColor Cyan
aws s3 sync . "s3://$bucket" --delete --exclude "*" --include "*.html" --include "*.css" --include "*.js" --exclude "aws/*" --cache-control "no-cache"

Write-Host "Limpando cache do CloudFront ($dist)..." -ForegroundColor Cyan
aws cloudfront create-invalidation --distribution-id $dist --paths "/*" | Out-Null

Write-Host "`nPublicado com sucesso!" -ForegroundColor Green
Write-Host "Endereço do seu site: $siteUrl" -ForegroundColor Yellow
