'use strict';
const c = require('../lib/common');

/* POST /login  { nome, senha } */
exports.login = c.wrap('none', async ({ body }) => {
  const nome = String(body.nome || ''), senha = String(body.senha || '');
  const k = c.normNome(nome);
  if (!k || !senha || senha.length > 256) return c.fail('Informe nome e senha.', 400);

  /* bloqueio por nome: 5 erros seguidos = 30 s (valor guardado no DynamoDB, vale para qualquer navegador) */
  const lock = (await c.db.get('LOCK', k)) || { n: 0, until: 0 };
  if (lock.until > Date.now()) {
    return c.fail('Muitas tentativas. Aguarde ' + Math.ceil((lock.until - Date.now()) / 1000) + ' s.', 429, 'locked');
  }
  const cands = (await c.listUsers()).filter((u) => c.normNome(u.nome) === k);
  if (!cands.length) return c.fail('Usuário não encontrado. Abra um ticket no Discord para solicitar seu acesso.', 401, 'nouser');

  const res = await Promise.all(cands.map(async (u) => (c.safeEq(await c.derive(senha, u.salt), u.hash) ? u : null)));
  const u = res.find(Boolean);
  if (!u) {
    lock.n = (lock.n || 0) + 1;
    if (lock.n >= 5) { lock.until = Date.now() + 30000; lock.n = 0; }
    await c.db.put({ pk: 'LOCK', sk: k, n: lock.n, until: lock.until, ttl: Math.floor(Date.now() / 1000) + 3600 });
    return c.fail('Senha incorreta.', 401, 'badpass');
  }
  if (lock.n || lock.until) await c.db.del('LOCK', k);
  const s = c.signToken(u.id);
  return c.ok({ token: s.token, expiresAt: s.expiresAt, user: c.pub(u) });
});

/* GET /me */
exports.me = c.wrap('user', async ({ me }) => c.ok({ user: c.pub(me) }));
