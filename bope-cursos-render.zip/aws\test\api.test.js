'use strict';
process.env.DB_DRIVER = 'memory';
process.env.JWT_SECRET = 'segredo-de-teste-com-mais-de-32-caracteres';
const test = require('node:test');
const assert = require('node:assert/strict');
const c = require('../src/lib/common');
const A = require('../src/handlers/auth');
const D = require('../src/handlers/data');
const U = require('../src/handlers/users');
const G = require('../src/handlers/cargos');
const K = require('../src/handlers/courses');
const C = require('../src/handlers/certs');
const R = require('../src/handlers/records');
const B = require('../src/handlers/backup');

/* chama um handler como o API Gateway faria */
async function call(fn, { token, body, params } = {}) {
  const r = await fn({ headers: token ? { authorization: 'Bearer ' + token } : {}, body: body === undefined ? undefined : JSON.stringify(body), pathParameters: params });
  return Object.assign({ status: r.statusCode }, JSON.parse(r.body));
}
let admin, user;
async function login(nome, senha) { return call(A.login, { body: { nome, senha } }); }

test.beforeEach(async () => {
  c.db._reset(); c.resetSeedCache();
  await c.ensureSeed();
  const cr = await c.newCreds('senhaAdmin1');
  await c.db.put({ pk: 'USER', sk: 'adm', id: 'ADM', nome: 'Chefe Teste', cargo: 'CEO', instrutor: false, role: 'admin', fixo: false, salt: cr.salt, hash: cr.hash, criadoEm: '2026-01-01' });
  admin = (await login('chefe teste', 'senhaAdmin1')).token;
  await call(U.create, { token: admin, body: { id: 'joao', nome: 'João Silva', cargo: 'Membro', senha: 'senhaJoao12' } });
  user = (await login('joao silva', 'senhaJoao12')).token;
});

test('login: nome sem acento/maiúsculas, senha errada e usuário inexistente', async () => {
  assert.equal((await login('JOAO SILVA', 'senhaJoao12')).ok, true);
  const bad = await login('João Silva', 'errada123');
  assert.deepEqual([bad.status, bad.code], [401, 'badpass']);
  const none = await login('Ninguém', 'x');
  assert.deepEqual([none.status, none.code], [401, 'nouser']);
});

test('login: 5 erros bloqueiam por 30 s, mesmo com a senha certa', async () => {
  for (let i = 0; i < 5; i++) await login('João Silva', 'errada123');
  const r = await login('João Silva', 'senhaJoao12');
  assert.deepEqual([r.status, r.code], [429, 'locked']);
});

test('CEO fixo do seed existe e a resposta nunca vaza salt/hash', async () => {
  const b = await call(D.bootstrap, { token: admin });
  assert.ok(b.users.some((u) => u.id === 'CEO' && u.fixo));
  assert.ok(!JSON.stringify(b).includes('hash'));
  assert.deepEqual(b.cargos, ['Diretor', 'Instrutor', 'Membro']);
  assert.equal(b.courses.length, 6);
});

test('autorização: sem token = 401, usuário comum nas rotas de admin = 403, token adulterado = 401', async () => {
  assert.equal((await call(D.bootstrap)).status, 401);
  assert.equal((await call(U.create, { token: user, body: {} })).status, 403);
  assert.equal((await call(R.notes.create, { token: user, body: {} })).status, 403);
  assert.equal((await call(D.bootstrap, { token: user.slice(0, -2) + 'xx' })).status, 401);
  const b = await call(D.bootstrap, { token: user });
  assert.deepEqual([b.users, b.certs, b.notes, b.punicoes], [[], [], [], []]);
});

test('usuários: duplicidade de ID/nome, validações, edição, reset de senha e exclusão em cascata', async () => {
  const dup = (body) => call(U.create, { token: admin, body: Object.assign({ cargo: 'Membro', senha: 'senha1234' }, body) });
  assert.match((await dup({ id: 'JOAO', nome: 'Outro' })).error, /ID/);
  assert.match((await dup({ id: 'novo1', nome: 'joao  SILVA' })).error, /nome/);
  assert.match((await dup({ id: 'a', nome: 'Fulano' })).error, /ID deve ter/);
  assert.match((await dup({ id: 'novo2', nome: 'Fulano', senha: 'curta' })).error, /senha/);
  assert.match((await dup({ id: 'novo3', nome: 'Fulano', cargo: 'Inexistente' })).error, /cargo/);

  assert.equal((await call(U.update, { token: admin, params: { id: 'joao' }, body: { nome: 'João S.', cargo: 'Diretor', instrutor: true } })).ok, true);
  assert.equal((await call(U.resetPassword, { token: admin, params: { id: 'joao' }, body: { senha: 'novaSenha99' } })).ok, true);
  assert.equal((await login('João S.', 'novaSenha99')).ok, true);

  const course = (await call(D.bootstrap, { token: admin })).courses[0];
  await call(C.create, { token: admin, body: { userId: 'joao', cursoId: course.id, data: '2026-11-01' } });
  assert.equal((await call(U.remove, { token: admin, params: { id: 'joao' } })).ok, true);
  assert.equal((await call(D.bootstrap, { token: admin })).certs.length, 0);
  assert.equal((await call(U.remove, { token: admin, params: { id: 'ADM' } })).ok, false);       /* admin não se exclui */
  assert.equal((await call(U.remove, { token: admin, params: { id: 'CEO' } })).ok, false);
});

test('admin fixo: só o status de instrutor muda', async () => {
  await call(U.update, { token: admin, params: { id: 'CEO' }, body: { nome: 'Outro', cargo: 'Membro', instrutor: true } });
  const ceo = (await call(D.bootstrap, { token: admin })).users.find((u) => u.id === 'CEO');
  assert.deepEqual([ceo.nome, ceo.cargo, ceo.instrutor], ['Albino', 'CEO', true]);
});

test('cargos: criar, duplicado, "CEO" reservado, não remover em uso', async () => {
  assert.equal((await call(G.create, { token: admin, body: { nome: 'Sargento' } })).ok, true);
  assert.match((await call(G.create, { token: admin, body: { nome: 'sargento' } })).error, /já existe/);
  assert.match((await call(G.create, { token: admin, body: { nome: 'ceo' } })).error, /já existe/);
  assert.match((await call(G.remove, { token: admin, params: { nome: 'Membro' } })).error, /usuários com esse cargo/);
  assert.equal((await call(G.remove, { token: admin, params: { nome: encodeURIComponent('Sargento') } })).ok, true);
  assert.ok(!(await call(D.bootstrap, { token: admin })).cargos.includes('Sargento'));
});

test('cursos: CRUD, validações e leitura por usuário comum', async () => {
  const novo = await call(K.create, { token: admin, body: { titulo: 'Curso Novo', link: 'https://exemplo.com' } });
  assert.equal(novo.ok, true);
  assert.match((await call(K.create, { token: admin, body: { titulo: 'x' } })).error, /título/);
  assert.match((await call(K.create, { token: admin, body: { titulo: 'Válido', link: 'ftp://x' } })).error, /link/);
  assert.equal((await call(K.update, { token: admin, params: { id: novo.id }, body: { titulo: 'Renomeado' } })).ok, true);
  const list = (await call(D.bootstrap, { token: user })).courses;
  assert.equal(list[list.length - 1].titulo, 'Renomeado');      /* ordem de criação preservada */
  assert.equal((await call(K.remove, { token: admin, params: { id: novo.id } })).ok, true);
  assert.equal((await call(K.remove, { token: admin, params: { id: novo.id } })).status, 404);
});

test('certificados: duplicado, instrutor inativo, nome do curso congelado, visibilidade por usuário', async () => {
  const [c1, c2] = (await call(D.bootstrap, { token: admin })).courses;
  const emit = (body) => call(C.create, { token: admin, body });
  assert.equal((await emit({ userId: 'joao', cursoId: c1.id, data: '2026-11-01' })).ok, true);
  assert.match((await emit({ userId: 'joao', cursoId: c1.id, data: '2026-11-02' })).error, /já tem certificado/);
  assert.match((await emit({ userId: 'joao', cursoId: c2.id, data: '01/11/2026' })).error, /data/);
  assert.match((await emit({ userId: 'joao', cursoId: c2.id, data: '2026-11-01', instrutorId: 'joao' })).error, /Instrutor ativo/);
  await call(U.update, { token: admin, params: { id: 'joao' }, body: { nome: 'João Silva', cargo: 'Membro', instrutor: true } });
  assert.equal((await emit({ userId: 'CEO', cursoId: c2.id, data: '2026-11-01', instrutorId: 'joao' })).ok, true);

  await call(K.update, { token: admin, params: { id: c1.id }, body: { titulo: 'Título Novo' } });
  const mine = (await call(D.bootstrap, { token: user })).myCerts;
  assert.equal(mine.length, 1);
  assert.equal(mine[0].curso, c1.titulo);                         /* certificado antigo mantém o nome emitido */
  assert.equal((await call(D.bootstrap, { token: admin })).certs.length, 2);
  assert.equal((await call(C.remove, { token: admin, params: { id: mine[0].id } })).ok, true);
});

test('anotações e punições: criar, validar, editar com autoria e remover', async () => {
  const n = await call(R.notes.create, { token: admin, body: { nome: 'Fulano', texto: 'Relato' } });
  assert.equal(n.ok, true);
  assert.match((await call(R.notes.create, { token: admin, body: { nome: 'Fulano', texto: '' } })).error, /observações/);
  await call(R.notes.update, { token: admin, params: { id: n.id }, body: { nome: 'Fulano', texto: 'Editado' } });
  const note = (await call(D.bootstrap, { token: admin })).notes[0];
  assert.deepEqual([note.texto, note.registradoPor, note.editadoPor], ['Editado', 'Chefe Teste', 'Chefe Teste']);
  assert.equal((await call(R.notes.remove, { token: admin, params: { id: n.id } })).ok, true);
  assert.equal((await call(R.notes.remove, { token: admin, params: { id: n.id } })).status, 404);

  assert.match((await call(R.punicoes.create, { token: admin, body: { autor: 'A1', punido: 'P1', motivo: 'x' } })).error, /motivo/);
  assert.equal((await call(R.punicoes.create, { token: admin, body: { autor: 'Autor', punido: 'Punido', motivo: 'Motivo válido' } })).ok, true);
  assert.equal((await call(D.bootstrap, { token: admin })).punicoes.length, 1);
});

test('backup: exporta, importa em base limpa e recria o CEO fixo', async () => {
  await call(R.notes.create, { token: admin, body: { nome: 'Fulano', texto: 'Relato' } });
  const { backup } = await call(B.export, { token: admin });
  assert.equal(backup.users.length, 3);
  assert.equal((await call(B.export, { token: user })).status, 403);

  const semCeo = Object.assign({}, backup, { users: backup.users.filter((u) => u.id !== 'CEO') });
  c.db._reset(); c.resetSeedCache();
  await c.ensureSeed();                                           /* base nova só com o CEO + dados padrão */
  const adm = await call(A.login, { body: { nome: 'Albino', senha: 'não sei' } });
  assert.equal(adm.status, 401);
  /* entra como o admin do backup: reinsere ADM manualmente só para autenticar a chamada */
  await c.db.put(Object.assign({ pk: 'USER', sk: 'adm' }, backup.users.find((u) => u.id === 'ADM')));
  const r = await call(B.import, { token: admin, body: { backup: semCeo } });
  assert.equal(r.ok, true);
  const b = await call(D.bootstrap, { token: admin });
  assert.deepEqual(b.users.map((u) => u.id).sort(), ['ADM', 'CEO', 'joao']);
  assert.equal(b.notes.length, 1);
  assert.equal((await login('joao silva', 'senhaJoao12')).ok, true);   /* hashes do backup continuam válidos */

  assert.match((await call(B.import, { token: admin, body: { backup: { users: [], cargos: [], certs: [] } } })).error, /administrador/);
  assert.match((await call(B.import, { token: admin, body: {} })).error, /inválido/);
});

test('hash compatível com o auth.js original (Web Crypto PBKDF2, 150 mil iterações, SHA-256)', async () => {
  const { subtle } = require('node:crypto').webcrypto;
  const key = await subtle.importKey('raw', new TextEncoder().encode('Sénha çom acentos'), 'PBKDF2', false, ['deriveBits']);
  const bits = await subtle.deriveBits({ name: 'PBKDF2', salt: Buffer.from(c.SEED.salt, 'base64'), iterations: 150000, hash: 'SHA-256' }, key, 256);
  assert.equal(await c.derive('Sénha çom acentos', c.SEED.salt), Buffer.from(bits).toString('base64'));
});
