'use strict';
const c = require('../lib/common');
const DUP_NOME = 'Já existe um usuário com esse nome. O nome é usado no login e precisa ser único.';
const nameTaken = (list, nome, exceptId) => list.some((u) => c.normNome(u.nome) === c.normNome(nome) && c.lc(u.id) !== c.lc(exceptId));

/* POST /users  { id, nome, cargo, instrutor, senha } */
exports.create = c.wrap('admin', async ({ body: d }) => {
  const e = c.vNome(d.nome) || c.vId(d.id) || c.vSenha(d.senha);
  if (e) return c.fail(e);
  if (!(await c.listCargos()).includes(d.cargo)) return c.fail('Selecione um cargo válido.');
  const list = await c.listUsers();
  if (list.some((u) => c.lc(u.id) === c.lc(d.id))) return c.fail('Já existe um usuário com esse ID.');
  if (nameTaken(list, d.nome)) return c.fail(DUP_NOME);
  const cr = await c.newCreds(String(d.senha));
  const done = await c.db.putNew({
    pk: 'USER', sk: c.lc(d.id), id: String(d.id), nome: String(d.nome).trim().replace(/\s+/g, ' '), cargo: d.cargo,
    instrutor: !!d.instrutor, role: 'user', salt: cr.salt, hash: cr.hash, criadoEm: c.today()
  });
  return done ? c.ok() : c.fail('Já existe um usuário com esse ID.');
});

/* PUT /users/{id}  { nome, cargo, instrutor } — o admin fixo só muda "instrutor" */
exports.update = c.wrap('admin', async ({ params, body: d }) => {
  const u = await c.db.get('USER', c.lc(params.id));
  if (!u) return c.fail('Usuário não encontrado.', 404);
  if (u.role !== 'admin') {
    const e = c.vNome(d.nome); if (e) return c.fail(e);
    if (nameTaken(await c.listUsers(), d.nome, u.id)) return c.fail(DUP_NOME);
    if (!(await c.listCargos()).includes(d.cargo)) return c.fail('Selecione um cargo válido.');
    u.cargo = d.cargo;
    u.nome = String(d.nome).trim().replace(/\s+/g, ' ');
  }
  u.instrutor = !!d.instrutor;
  await c.db.put(u);
  return c.ok();
});

/* POST /users/{id}/password  { senha } */
exports.resetPassword = c.wrap('admin', async ({ params, body: d }) => {
  const e = c.vSenha(d.senha); if (e) return c.fail(e);
  const u = await c.db.get('USER', c.lc(params.id));
  if (!u) return c.fail('Usuário não encontrado.', 404);
  const cr = await c.newCreds(String(d.senha));
  u.salt = cr.salt; u.hash = cr.hash;
  await c.db.put(u);
  return c.ok();
});

/* DELETE /users/{id} — apaga também os certificados do usuário */
exports.remove = c.wrap('admin', async ({ me, params }) => {
  const u = await c.db.get('USER', c.lc(params.id));
  if (!u) return c.fail('Usuário não encontrado.', 404);
  if (u.role === 'admin' || c.lc(u.id) === c.lc(me.id)) return c.fail('O administrador não pode ser excluído.');
  for (const ct of await c.db.query('CERT')) if (c.lc(ct.userId) === c.lc(u.id)) await c.db.del('CERT', ct.sk);
  await c.db.del('USER', u.sk);
  return c.ok();
});
