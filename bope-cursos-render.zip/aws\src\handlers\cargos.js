'use strict';
const c = require('../lib/common');

/* POST /cargos  { nome } */
exports.create = c.wrap('admin', async ({ body }) => {
  const nome = String(body.nome || '').trim();
  if (nome.length < 2 || nome.length > 40) return c.fail('O cargo deve ter de 2 a 40 caracteres.');
  const list = await c.listCargos();
  if (nome.toLowerCase() === 'ceo' || list.some((x) => x.toLowerCase() === nome.toLowerCase())) return c.fail('Esse cargo já existe.');
  await c.db.put({ pk: 'CARGO', sk: nome, nome, ordem: Date.now() });
  return c.ok();
});

/* DELETE /cargos/{nome}  (o nome vai codificado na URL) */
exports.remove = c.wrap('admin', async ({ params }) => {
  let nome = params.nome || '';
  try { nome = decodeURIComponent(nome); } catch (e) { /* já veio decodificado */ }
  if ((await c.listUsers()).some((u) => u.cargo === nome)) return c.fail('Há usuários com esse cargo. Altere o cargo deles antes de remover.');
  await c.db.del('CARGO', nome);
  return c.ok();
});
