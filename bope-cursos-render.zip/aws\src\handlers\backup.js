'use strict';
const c = require('../lib/common');

/* GET /backup — inclui hashes de senha: só o administrador acessa */
exports.export = c.wrap('admin', async () => {
  const [users, cargos, certs, courses, notes, punicoes] = await Promise.all([
    c.listUsers(), c.listCargos(), c.listCerts(), c.listCourses(), c.listRecs('NOTE'), c.listRecs('PUN')
  ]);
  return c.ok({ backup: { v: 1, users, cargos, certs, courses, notes, punicoes } });
});

function cleanRecs(list, fields) {
  if (!Array.isArray(list)) return null;
  return list.filter((r) => r && typeof r.id === 'string' && fields.every((f) => typeof r[f[0]] === 'string')).map((r) => {
    const x = { id: r.id.slice(0, 40), criadoEm: String(r.criadoEm || '').slice(0, 40), registradoPor: String(r.registradoPor || '').slice(0, 80) };
    fields.forEach((f) => { x[f[0]] = r[f[0]].slice(0, f[1]); });
    if (r.editadoEm) { x.editadoEm = String(r.editadoEm).slice(0, 40); x.editadoPor = String(r.editadoPor || '').slice(0, 80); }
    return x;
  });
}

/* POST /backup  { backup: {...} } — substitui usuários, cargos e certificados; cursos, anotações e punições só se vierem no arquivo */
exports.import = c.wrap('admin', async ({ body }) => {
  const o = body.backup;
  if (!o || !Array.isArray(o.users) || !Array.isArray(o.cargos) || !Array.isArray(o.certs)) return c.fail('Arquivo inválido.');
  const good = o.users.every((u) => u && c.ID_RE.test(String(u.id)) && typeof u.nome === 'string' && typeof u.salt === 'string' && typeof u.hash === 'string' && (u.role === 'admin' || u.role === 'user'));
  if (!good || !o.users.some((u) => u.role === 'admin')) return c.fail('O backup precisa ter usuários válidos e um administrador.');

  const cargos = o.cargos.filter((x) => typeof x === 'string' && x.length >= 1 && x.length <= 40);
  const certs = o.certs.filter((x) => x && typeof x.id === 'string' && typeof x.userId === 'string' && typeof x.curso === 'string' && x.curso.length <= 80 && c.DATE_RE.test(String(x.data)))
    .map((x) => ({
      id: x.id.slice(0, 40), userId: x.userId, cursoId: typeof x.cursoId === 'string' ? x.cursoId : '', curso: x.curso, data: x.data,
      emitidoPor: String(x.emitidoPor || '').slice(0, 80), instrutorId: String(x.instrutorId || '').slice(0, 20), instrutorNome: String(x.instrutorNome || '').slice(0, 80),
      emitidoEm: c.DATE_RE.test(String(x.emitidoEm || '')) ? x.emitidoEm : ''
    }));
  const notes = cleanRecs(o.notes, [['nome', 80], ['texto', 4000]]);
  const puns = cleanRecs(o.punicoes, [['autor', 80], ['punido', 80], ['motivo', 2000]]);

  let courses = null;
  if (Array.isArray(o.courses)) {
    courses = [];
    for (const x of o.courses) {
      const v = c.vCourse(x || {});
      if (v.error || typeof (x || {}).id !== 'string' || !/^c[a-z0-9]{1,20}$/.test(x.id)) return c.fail('O backup tem um curso inválido.');
      courses.push(Object.assign({ id: x.id }, v.value));
    }
  }
  const users = o.users.map((u) => ({
    id: String(u.id), nome: String(u.nome).slice(0, 80), cargo: u.role === 'admin' ? 'CEO' : String(u.cargo || ''), instrutor: !!u.instrutor,
    role: u.role, fixo: String(u.id) === c.SEED.id, salt: u.salt, hash: u.hash, criadoEm: String(u.criadoEm || '')
  }));

  await c.db.replaceAll('USER', users.map((u) => Object.assign({ pk: 'USER', sk: c.lc(u.id) }, u)));
  await c.db.replaceAll('CARGO', cargos.map((n, i) => ({ pk: 'CARGO', sk: n, nome: n, ordem: i })));
  await c.db.replaceAll('CERT', certs.map((x) => Object.assign({ pk: 'CERT', sk: x.id }, x)));
  if (courses) await c.db.replaceAll('COURSE', courses.map((x, i) => Object.assign({ pk: 'COURSE', sk: x.id, ordem: i }, x)));
  if (notes) await c.db.replaceAll('NOTE', notes.map((x) => Object.assign({ pk: 'NOTE', sk: x.id }, x)));
  if (puns) await c.db.replaceAll('PUN', puns.map((x) => Object.assign({ pk: 'PUN', sk: x.id }, x)));
  c.resetSeedCache();
  await c.ensureSeed();               /* o CEO fixo é recriado se o backup não o trouxer */
  return c.ok();
});
