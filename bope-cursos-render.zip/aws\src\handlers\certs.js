'use strict';
const c = require('../lib/common');

/* POST /certs  { userId, cursoId, data, instrutorId? } */
exports.create = c.wrap('admin', async ({ me, body: d }) => {
  const user = await c.db.get('USER', c.lc(d.userId));
  if (!user) return c.fail('Selecione um usuário.');
  const course = await c.db.get('COURSE', String(d.cursoId || ''));
  if (!course) return c.fail('Selecione um curso.');
  if (!c.DATE_RE.test(String(d.data || ''))) return c.fail('Informe a data de conclusão.');
  const certs = await c.db.query('CERT');
  if (certs.some((x) => c.lc(x.userId) === c.lc(user.id) && (x.cursoId ? x.cursoId === course.id : x.curso === course.titulo))) {
    return c.fail('Esse usuário já tem certificado desse curso.');
  }
  /* instrutor responsável (opcional): precisa estar com "Instrutor ativo" = Sim */
  let instr = null;
  if (d.instrutorId) {
    instr = await c.db.get('USER', c.lc(d.instrutorId));
    if (!instr || !instr.instrutor) return c.fail('O instrutor selecionado precisa estar com "Instrutor ativo" = Sim.');
  }
  /* nome do curso e do instrutor ficam gravados: renomear depois não altera certificados já emitidos */
  const id = c.rid();
  await c.db.put({
    pk: 'CERT', sk: id, id, userId: user.id, cursoId: course.id, curso: course.titulo, data: d.data, emitidoPor: me.nome,
    instrutorId: instr ? instr.id : '', instrutorNome: instr ? instr.nome : '', emitidoEm: c.today()
  });
  return c.ok({ id });
});

/* DELETE /certs/{id} */
exports.remove = c.wrap('admin', async ({ params }) => {
  await c.db.del('CERT', params.id);
  return c.ok();
});
