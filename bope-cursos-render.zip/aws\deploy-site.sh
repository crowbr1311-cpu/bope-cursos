#!/usr/bin/env bash
# Envia os arquivos do site para o S3 e limpa o cache do CloudFront.
# Uso (dentro da pasta aws):  ./deploy-site.sh [nome-do-stack]     (padrão: bope-cursos)
set -euo pipefail
STACK="${1:-bope-cursos}"
cd "$(dirname "$0")/.."            # raiz do site

output() { aws cloudformation describe-stacks --stack-name "$STACK" \
  --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text; }
BUCKET="$(output SiteBucket)"
DIST="$(output DistributionId)"
[ -n "$BUCKET" ] && [ "$BUCKET" != "None" ] || { echo "Stack '$STACK' não encontrado (ou sem saída SiteBucket)." >&2; exit 1; }

# só HTML/CSS/JS da raiz; a pasta aws/ nunca sobe. "no-cache" = o navegador revalida a cada acesso (usa ETag).
aws s3 sync . "s3://$BUCKET" --delete \
  --exclude "*" --include "*.html" --include "*.css" --include "*.js" --exclude "aws/*" \
  --cache-control "no-cache"
aws cloudfront create-invalidation --distribution-id "$DIST" --paths "/*" >/dev/null
echo "Publicado: $(output SiteUrl)"
