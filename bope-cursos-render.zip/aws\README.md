# B.O.P.E Cursos — backend na AWS

O projeto original não tinha Netlify Functions: toda a lógica rodava no navegador (`auth.js` + `localStorage`).
Agora ela roda em **funções Lambda** (Node.js 20) atrás de um **API Gateway HTTP**, com dados no **DynamoDB**.
O `netlify.toml` foi removido; o site é HTML/CSS/JS estático e vai para um bucket S3 atrás de um CloudFront.

## Testar no computador (sem AWS)

```bash
cd aws
npm run local        # abre http://localhost:3000 (site + API, usando as mesmas funções)
```

Os dados ficam em `aws/local/data.json`. Em `localhost` o site usa esse servidor automaticamente, sem mexer no `config.js`.
O login inicial é o CEO fixo (`Albino`) com a senha que você já usava. Esse servidor é só para desenvolvimento: não o exponha na internet.

## Como publicar (API + site no S3 com HTTPS)

Requisitos: conta AWS, AWS CLI configurado (`aws configure`), [SAM CLI](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html), Node 20+.

```bash
cd aws
npm test                                        # 14 testes, sem precisar de AWS
sam build
sam deploy --guided --stack-name bope-cursos    # pode aceitar os padrões
./deploy-site.sh bope-cursos                    # envia os arquivos do site ao S3 e limpa o cache
```

Ao final, `Outputs` mostra o **SiteUrl** (`https://xxxx.cloudfront.net`): é o endereço do seu site. Nada mais para configurar.

Como as peças se ligam:

```
navegador ──HTTPS──> CloudFront ──/*──────> S3 (bucket privado, só o CloudFront lê)
                         └──────/prod/*──> API Gateway HTTP ──> 22 funções Lambda ──> DynamoDB
```

O site chama a API em `/prod/...` (valor padrão de `apiUrl` no `config.js`), no mesmo endereço em que foi aberto. Por isso não há CORS e a CSP
continua só com `'self'`. Os headers de segurança que estavam no `netlify.toml` (CSP, nosniff, DENY, no-referrer, noindex), mais o HSTS,
são aplicados pelo CloudFront.

**Atualizar o site depois:** edite os arquivos e rode `./deploy-site.sh` de novo. **Atualizar a API:** `sam build && sam deploy`.

**Já tem um bucket S3 próprio?** O template cria um bucket novo e privado; o mais simples é enviar os arquivos para ele. Se preferir manter o seu,
informe o endereço dele em `AllowedOrigin` no deploy (ex. `https://meusite.com.br`) e coloque a `ApiUrl` completa em `apiUrl` no `config.js`.
Atenção: bucket com "static website hosting" só serve HTTP, e o login deve ser usado em HTTPS; prefira o CloudFront.

**Domínio próprio:** adicione um certificado do ACM (região us-east-1) e o domínio em `Aliases` da distribuição.

## Solução de problemas

**"A API respondeu HTTP xxx sem ser JSON" / "Resposta inválida do servidor"** — a chamada `/prod/...` não chegou às funções. Teste direto (troque pelo seu SiteUrl):

```bash
curl -i -X POST https://xxxx.cloudfront.net/prod/login -H 'Content-Type: application/json' -d '{"nome":"x","senha":"y"}'
```

- Volta `{"ok":false,...,"code":"nouser"}` → a API está ok; limpe o cache do navegador e confirme que `config.js` no S3 tem `apiUrl: '/prod'` (rode `./deploy-site.sh`).
- Volta HTML/XML (`NoSuchKey`, `AccessDenied`, 404) → o site não está aberto pelo CloudFront deste stack (ex. você abriu a URL do bucket S3). Use o `SiteUrl`.
- Volta `{"message":"Forbidden"}` ou `Not Found` → confira o nome do stage: `Stage` no deploy deve ser igual ao do `apiUrl` (`/prod` por padrão).
- Volta `{"message":"Internal Server Error"}` → erro na função; veja os logs: `sam logs --stack-name bope-cursos --name LoginFunction --tail`.
- Distribuição recém-criada leva alguns minutos para ficar "Deployed".

## Funções e rotas

| Função (Lambda) | Rota | Quem acessa |
|---|---|---|
| `auth.login` | `POST /login` | público |
| `auth.me` | `GET /me` | logado |
| `data.bootstrap` | `GET /bootstrap` (cursos, cargos, meus certificados; admin: tudo) | logado |
| `users.create / update / resetPassword / remove` | `POST /users`, `PUT /users/{id}`, `POST /users/{id}/password`, `DELETE /users/{id}` | admin |
| `cargos.create / remove` | `POST /cargos`, `DELETE /cargos/{nome}` | admin |
| `courses.create / update / remove` | `POST /courses`, `PUT·DELETE /courses/{id}` | admin |
| `certs.create / remove` | `POST /certs`, `DELETE /certs/{id}` | admin |
| `records.notes.*` / `records.punicoes.*` | `POST /notes`, `PUT·DELETE /notes/{id}` (idem `/punicoes`) | admin |
| `backup.export / import` | `GET /backup`, `POST /backup` | admin |

## O que mudou em relação à versão com `localStorage`

- **Senhas e regras agora são validadas no servidor.** O navegador só envia a senha uma vez (HTTPS) no login; o hash PBKDF2 (mesmo formato de antes) fica no DynamoDB.
- **Sessão** = token JWT assinado (8 h) guardado em `sessionStorage`. O papel (admin/usuário) é lido do banco a cada chamada, nunca do token. Não há revogação antes de expirar.
- **Bloqueio de login** (5 erros = 30 s) agora vale para qualquer navegador, por nome de usuário.
- **Backups antigos continuam válidos**: Administração → Importar aceita o arquivo gerado pela versão anterior.
  Para migrar, exporte o backup na versão antiga, publique esta e importe.
- O CEO fixo (`CEO` / Albino) e os cargos/cursos padrão são criados automaticamente na primeira chamada.
- A chave do JWT é gerada pelo Secrets Manager no deploy. A tabela DynamoDB tem backup contínuo (PITR) e não é apagada se a stack for removida.
- A importação de backup não é atômica (apaga e regrava item a item): faça-a sem outras pessoas editando.
