'use strict';
/* Servidor de desenvolvimento: serve o site e a API (mesmas funções Lambda) em http://localhost:3000.
   Dados ficam em aws/local/data.json. Não usa AWS e NÃO deve ser exposto na internet. */
const path = require('path'), fs = require('fs'), http = require('http');
process.env.DB_DRIVER = 'memory';
process.env.DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data.json');
process.env.JWT_SECRET = process.env.JWT_SECRET || 'chave-apenas-para-desenvolvimento-local-0123456789';

const SITE = path.join(__dirname, '../..');
const tpl = fs.readFileSync(path.join(__dirname, '../template.yaml'), 'utf8');
const routes = [...tpl.matchAll(/Handler: handlers\/(\S+)[\s\S]*?Method: (\w+), Path: "([^"]+)"/g)].map((m) => {
  let fn = require('../src/handlers/' + m[1].split('.')[0]);
  m[1].split('.').slice(1).forEach((k) => { fn = fn[k]; });
  return { fn, method: m[2], re: new RegExp('^' + m[3].replace(/\{(\w+)\}/g, '(?<$1>[^/]+)') + '$') };
});
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };

http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/prod/')) {
    const p = url.pathname.slice(5);
    const hit = routes.map((r) => ({ r, m: r.re.exec(p) })).find((x) => x.m && x.r.method === req.method);
    if (!hit) { res.writeHead(404, { 'Content-Type': 'application/json' }); return res.end('{"ok":false,"error":"Rota não encontrada."}'); }
    const chunks = [];
    req.on('data', (d) => chunks.push(d));
    req.on('end', async () => {
      const out = await hit.r.fn({ headers: req.headers, body: Buffer.concat(chunks).toString() || undefined, pathParameters: Object.assign({}, hit.m.groups) });
      res.writeHead(out.statusCode, out.headers); res.end(out.body);
    });
    return;
  }
  const name = url.pathname === '/' ? 'login.html' : decodeURIComponent(url.pathname.slice(1));
  const file = path.join(SITE, name);
  if (!/^[\w.-]+\.(html|js|css)$/.test(name) || !file.startsWith(SITE + path.sep) || !fs.existsSync(file)) { res.writeHead(404); return res.end('Não encontrado'); }
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] }); res.end(fs.readFileSync(file));
}).listen(process.env.PORT || 3000, () => console.log('B.O.P.E local: http://localhost:' + (process.env.PORT || 3000)));
